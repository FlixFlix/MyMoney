/**
 * Created by robertmartindelcampo on 5/17/17.
 */
(function() {
	'use strict';

	angular
		.module( 'mitek-sdk', [] );
})();
